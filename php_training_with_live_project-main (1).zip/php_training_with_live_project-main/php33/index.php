
   <?php include 'header.php'; ?>

    <section class="maincontent">
    <?php
echo "Main Section"
    ?>
    </section>


    <?php include 'footer.php'; ?>